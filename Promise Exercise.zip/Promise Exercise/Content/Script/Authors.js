function showData() {
    let url = `${"https://fakerestapi.azurewebsites.net/api/v1/Authors"}`
    let p = fetch(url).then(function (response) {
        return response.json()
    }).then(function (d) {
        console.log(d)
        let tbody = document.querySelector("tbody")
        tbody.innerHTML = ""
        let x = d.length;
        for (let i = 0; i < x; i++) {
        let tablerow = `<tr> 
                        <td> ${d[i].id} </td>
                        <td> ${d[i].idBook} </td>
                        <td> ${d[i].firstName} </td>
                        <td> ${d[i].lastName} </td>
                        </tr>`
                
             tbody.innerHTML = tbody.innerHTML + tablerow;
        }
    
    })
}
