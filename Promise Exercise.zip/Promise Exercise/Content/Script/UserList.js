function showData() {
    let url = `${"https://fakerestapi.azurewebsites.net/api/v1/Users"}`
    let p = fetch(url).then(function (response) {
        return response.json()
    }).then(function (d) {
        console.log(d)
        let tbody = document.querySelector("tbody")
        tbody.innerHTML = ""
        let x = d.length;
        for (let i = 0; i < x; i++) {
        let tablerow = `<tr> 
                        <td> ${d[i].id} </td>
                        <td> ${d[i].userName} </td>
                        <td> ${d[i].password} </td>
                        </tr>`

            tbody.innerHTML = tbody.innerHTML + tablerow;
        }
    
    })
}
