﻿using System;

namespace Exercise4
{
    class Program
    {
        static public bool CheckArmstrong(int value)
        {
            int r, temp = value, sum = 0;
            while (temp > 0)
            {
                r = temp % 10;
                sum = sum + (r * r * r);
                temp = temp / 10;
            }
            if (sum == value)
            {
                return true;
            }
            else
                return false;

        }
        static void Main(string[] args)
        {
            int a, b;
            Console.WriteLine("Enter first number: ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second number: ");
            b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Armstrong Numbers: ");
            for(int i=a; i<b; i++)
            {
                if (CheckArmstrong(i))
                    Console.WriteLine(i);
            }
        }
    }
}
