﻿using System;

namespace Exercise2
{
    class Program
    {
        public class Arithmetic
        {
            float a, b;
            static public float Addition(float a, float b)
            {
                return a + b;
            }
            static public float Subtraction(float a, float b)
            {
                return a - b;
            }
            static public float Multiplication(float a, float b)
            {
                return a * b;
            }
            static public float Division(float a, float b)
            {
                return a / b;
            }
        }
        static void Main(string[] args)
        {
            int choice = 5;
            float a, b;
            do
            {
                Console.Clear();
                Console.WriteLine("Enter first number: ");
                a = Convert.ToSingle(Console.ReadLine());
                Console.WriteLine("Enter second number: ");
                b = Convert.ToSingle(Console.ReadLine());
                Console.WriteLine("Enter 1 for addition");
                Console.WriteLine("Enter 2 for subtraction");
                Console.WriteLine("Enter 3 for multiplication");
                Console.WriteLine("Enter 4 for division");
                Console.WriteLine("Enter 5 to exit");
                Console.Write("Enter your choice = ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("The result is: " + Arithmetic.Addition(a, b));
                        break;
                    case 2:
                        Console.WriteLine("The result is: " + Arithmetic.Subtraction(a, b));
                        break;
                    case 3:
                        Console.WriteLine("The result is: " + Arithmetic.Multiplication(a, b));
                        break;
                    case 4:
                        Console.WriteLine("The result is: " + Arithmetic.Division(a, b));
                        break;
                    case 5:
                        Console.WriteLine("Thanks for visit!!!");
                        break;
                    default:
                        Console.WriteLine("Invalid Option");
                        break;
                }
                Console.WriteLine("Press Enter to continue....");
                Console.ReadLine();
            } while (choice != 5);
        }
    }
}
