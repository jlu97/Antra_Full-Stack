﻿using System;

namespace Exercise5
{
    class Program
    {
        static void Main(string[] args)
        {
            int rows, lastValue = 0;
            Console.Write("Enter the Number of Rows: ");
            rows = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    if (lastValue == 1)
                    {
                        Console.Write("0");
                        lastValue = 0;
                    }
                    else if (lastValue == 0)
                    {
                        Console.Write("1");
                        lastValue = 1;
                    }
                }
                Console.WriteLine();

            }
        }
    }
}