﻿using System;

namespace Exercise3
{
    class Program
    {
        static public string Reverse(string s)
        {
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string to be reverse:");
            string str = Console.ReadLine();
            Console.WriteLine("Reversed string: " + Reverse(str));
        }
    }
}
