﻿using System;

namespace Exercise6
{
    class Program
    {
        static void Main(string[] args)
        {
            int rows;
            Console.Write("Enter the Number of Rows: ");
            rows = Convert.ToInt32(Console.ReadLine());

            for(int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= rows - i; j++)
                    Console.Write(" ");
                for (int k = 1; k <= 2 * i - 1; k++)
                    Console.Write("*");
                Console.Write("\n");
            }

            for(int i = rows - 1; i >= 1; i--)
            {
                for (int j  = 1; j <= rows - i; j++)
                    Console.Write(" ");
                for (int k  = 1; k <= 2 * i - 1; k++)
                    Console.Write("*");
                Console.Write("\n");
            }
        }
    }
}
