﻿using System;

namespace Exercise7
{
    class Program
    {
        public class Transaction
        {
            private decimal balance = 1000;

            public decimal CheckBalance()
            {
                return balance;
            }
            public decimal Withdraw(decimal amount)
            {
                return balance = balance - amount;
            }
            public decimal Deposit(decimal amount)
            {
                return balance = balance + amount;
            }
        }
        static void Main(string[] args)
        {
            int pin, choice = 4, value = 0;
            do
            {
                Console.WriteLine("Enter Your PIN Number");
                pin = Convert.ToInt32(Console.ReadLine());
                if (pin == 123)
                {
                    Transaction transaction = new Transaction();
                    do
                    {
                        Console.Clear();
                        Console.WriteLine("********Welcome to ATM Service********");
                        Console.WriteLine("1. Check Balance");
                        Console.WriteLine("2. Withdraw Cash");
                        Console.WriteLine("3. Deposit Cash");
                        Console.WriteLine("4. Quit");
                        Console.WriteLine("**************************************");
                        Console.WriteLine("Enter your choice");
                        choice = Convert.ToInt32(Console.ReadLine());
                        switch (choice)
                        {
                            case 1:
                                Console.WriteLine("YOUR BALANCE IN RS: " + transaction.CheckBalance());
                                break;
                            case 2:
                                Console.WriteLine("Enter the amount you want to withdraw");
                                decimal amount1 = Convert.ToDecimal(Console.ReadLine());
                                Console.WriteLine("YOUR BALANCE NOW IN RS: " + transaction.Withdraw(amount1));
                                break;
                            case 3:
                                Console.WriteLine("Enter the amount you want to deposit");
                                decimal amount2 = Convert.ToDecimal(Console.ReadLine());
                                Console.WriteLine("YOUR BALANCE NOW IN RS: " + transaction.Deposit(amount2));
                                break;
                            case 4:
                                Console.Clear();
                                Console.WriteLine("Thanks for visit!!!");
                                break;
                            default:
                                Console.WriteLine("Invalid Option");
                                break;
                        }
                        Console.WriteLine("Press Enter to continue...");
                        Console.ReadLine();
                    } while (choice != 4);
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Wrong PIN. TRY AGAIN!!!");
                }
            } while (true);
        }
    }
}
